import streamlit as st
from datasets import load_dataset
from transformers import BertForSequenceClassification, BertTokenizer
import torch
import pandas as pd
import subprocess

pd.set_option('display.max_colwidth', None)

device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

model = BertForSequenceClassification.from_pretrained(
    r'C:\Users\berke\PycharmProjects\SentimentAnalysis\.venv\Lib\model').to(device)
tokenizer = BertTokenizer.from_pretrained(r'C:\Users\berke\PycharmProjects\SentimentAnalysis\.venv\Lib\model')

ds = load_dataset("turkish-nlp-suite/sinefil-movie-reviews")
test_verisi = ds['test']


def tokenize_function(examples):
    return tokenizer(examples['text'], padding="max_length", truncation=True, return_tensors="pt")


# Tokenize edilecek test verisini hazırlama
def tokenize_dataset(dataset):
    tokenized_data = []
    for example in dataset:
        tokenized_example = tokenizer(example['text'], padding="max_length", truncation=True, return_tensors="pt")
        tokenized_data.append(tokenized_example)
    return tokenized_data


tokenized_test_verisi = tokenize_dataset(test_verisi)


def predict_dataset(dataset, model, batch_size=16):
    model.eval()
    tahminler = []

    # Batch işlemi için indeksleme
    for i in range(0, len(dataset), batch_size):
        batch = dataset[i:i + batch_size]
        # Batch içindeki tüm text'leri tokenize et
        inputs = tokenizer([example['text'] for example in batch], return_tensors="pt", padding=True, truncation=True,
                           max_length=512).to(device)
        with torch.no_grad():
            outputs = model(**inputs)
            preds = torch.argmax(outputs.logits, dim=-1).tolist()
            tahminler.extend(preds)

    return tahminler


Duygular = {0: 'Pozitif', 1: 'Nötr', 2: 'Negatif'}

st.title('Film İncelemeleri Duygu Analizi')

tahmini_yorumlar = predict_dataset(test_verisi, model)

# Tahminler ve test verisi uzunluklarını kontrol et
if len(tahmini_yorumlar) != len(test_verisi):
    st.write("Hata: Tahminler ve test verisi uzunlukları eşleşmiyor.")
else:
    pozitif_yorumlar = [test_verisi[i]['text'] for i in range(len(test_verisi)) if tahmini_yorumlar[i] == 0]
    if not pozitif_yorumlar:
        st.write("Pozitif inceleme bulunamadı.")
    else:
        st.write("Pozitif incelemeler:")
        for i, review in enumerate(pozitif_yorumlar[:10]):
            st.write(f"{i + 1}. Yorum: {review}")

    for i in range(min(50, len(test_verisi))):
        kullanıcı_yorumları = test_verisi[i]['text']
        st.write(f"Yorum: {kullanıcı_yorumları} -> Tahmin: {Duygular[tahmini_yorumlar[i]]}")

app_path = r"C:\Users\berke\PycharmProjects\SentimentAnalysis\.venv\Lib\dsetTRAIN.py"
proc = subprocess.Popen(["streamlit", "run", app_path])

input("Kapatmak için Enter'a basın.")
proc.terminate()
