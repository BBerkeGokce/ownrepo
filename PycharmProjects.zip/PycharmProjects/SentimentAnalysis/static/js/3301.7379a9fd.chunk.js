"use strict";(self.webpackChunk_streamlit_app=self.webpackChunk_streamlit_app||[]).push([[3301],{70738:(t,e,a)=>{a.d(e,{Z:()=>l});var n=a(66845),i=a(7974),r=a.n(i),o=a(23175),s=a.n(o);const c=(0,a(1515).Z)("div",{target:"ecnfqzf0"})((()=>({"@media print":{display:"none"}})),"");var m=a(40864);const d=t=>{let{className:e,scriptRunId:a,numParticles:n,numParticleTypes:i,ParticleComponent:o}=t;return(0,m.jsx)(c,{className:s()(e,"stHidden"),"data-testid":`${e}`,children:r()(n).map((t=>{const e=Math.floor(Math.random()*i);return(0,m.jsx)(o,{particleType:e},a+t)}))})},l=(0,n.memo)(d)},69436:(t,e,a)=>{a.r(e),a.d(e,{NUM_FLAKES:()=>u,default:()=>v});var n=a(66845);const i=a.p+"static/media/flake-0.beded754e8024c73d9d2.png",r=a.p+"static/media/flake-1.8077dc154e0bf900aa73.png",o=a.p+"static/media/flake-2.e3f07d06933dd0e84c24.png";var s=a(70738),c=a(1515),m=a(7865);const d=function(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0;return Math.random()*(t-e)+e},l=(0,c.Z)("img",{target:"ekdfb790"})((t=>{let{theme:e}=t;return{position:"fixed",top:"-150px",marginLeft:"-75px",zIndex:e.zIndices.balloons,left:`${d(90,10)}vw`,animationDelay:`${d(4e3)}ms`,height:"150px",width:"150px",pointerEvents:"none",animationDuration:"3000ms",animationName:m.F4`
  from {
    transform:
      translateY(0)
      rotateX(${d(360)}deg)
      rotateY(${d(360)}deg)
      rotateZ(${d(360)}deg);
  }

  to {
    transform:
      translateY(calc(100vh + ${150}px))
      rotateX(0)
      rotateY(0)
      rotateZ(0);
  }
`,animationTimingFunction:"ease-in",animationDirection:"normal",animationIterationCount:1,opacity:1}}),"");var p=a(40864);const u=100,f=[i,r,o],g=f.length,h=t=>{let{particleType:e}=t;return(0,p.jsx)(l,{src:f[e]})},x=function(t){let{scriptRunId:e}=t;return(0,p.jsx)(s.Z,{className:"stSnow","data-testid":"stSnow",scriptRunId:e,numParticleTypes:g,numParticles:u,ParticleComponent:h})},v=(0,n.memo)(x)}}]);